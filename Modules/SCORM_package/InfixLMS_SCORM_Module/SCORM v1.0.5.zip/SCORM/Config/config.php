<?php

return [
    'name' => 'SCORM'
];
