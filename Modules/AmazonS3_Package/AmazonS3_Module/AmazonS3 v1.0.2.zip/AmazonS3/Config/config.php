<?php

return [
    'name' => 'AmazonS3'
];
