<?php

namespace Modules\AmazonS3\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;

class AmazonS3DatabaseSeeder extends Seeder
{

    public function run()
    {
        Model::unguard();


    }
}
