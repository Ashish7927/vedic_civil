<?php

namespace Modules\SCORM\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;

class SCORMDatabaseSeeder extends Seeder
{

    public function run()
    {
        Model::unguard();


    }
}
